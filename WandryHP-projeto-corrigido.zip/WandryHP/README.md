# WandryHP — Minecraft Java 1.21.4 / Fabric

Projeto Fabric independente para Java 21, Minecraft 1.21.4, Yarn `1.21.4+build.8` e Fabric API `0.119.3+1.21.4`.

## Recursos desta versão

- Sete varinhas registradas com modelos 3D e posições de mão convertidas dos modelos Blockbench fornecidos. A Bone utiliza o modelo correspondente disponível nos recursos.
- Preparação de 20 ticks com a pose vanilla de arco (primeira e terceira pessoa); ao soltar, a varinha manifesta apenas uma rajada decorativa de partículas na ponta.
- Roda circular com sete setores, abre com **G**, navegação por mouse, setas/A-D e teclas 1–7.
- Sincronização da seleção cliente-servidor via Custom Payload; a seleção altera somente a cor da manifestação visual.
- Seis props utilizáveis com anéis de partículas próprios: Amethyst, Bone, Celestial, Dragon, Magma e Widow.
- Vassoura 3D utilizável que ativa/desativa o voo vanilla em sobrevivência.
- Chapéu, pergaminho, grupo criativo, receitas e traduções pt_BR.
- Modelos `.bbmodel` de varinhas e props preservados em `blockbench/`.

## Estrutura

- `src/main/java/com/wandryhp/`: registros, itens e payload de rede.
- `src/main/java/com/wandryhp/client/`: roda circular e keybind.
- `src/main/resources/assets/`: modelos, definições de itens, texturas e traduções.
- `src/main/resources/data/`: receitas.
- `blockbench/`: arquivos Blockbench originais dos itens decorativos fornecidos.
- `docs/`: documentação e limites conhecidos.

## Abrir e compilar

Requisitos: JDK 21 e acesso à internet (Gradle 8.12, Fabric Loom 1.9.2, Minecraft 1.21.4, Yarn, Fabric API).

```
./gradlew build        # Windows: gradlew.bat build
```

O JAR de uso é criado em `build/libs/wandryhp-1.0.0.jar` (o `-sources.jar` é só o código-fonte). Para testar no cliente: `./gradlew runClient`.

## Controles

- **G**: abrir a roda circular.
- Mouse / setas / A-D: navegar; clique, Enter ou 1–7 confirma.
- Segurar botão direito com uma varinha por aproximadamente 1 segundo e soltar: animação de preparação e manifestação de partículas decorativas.
- Usar um prop: ativar sua manifestação visual.
- Usar a vassoura: ativar/desativar voo mágico.

## Limites conhecidos

- Esta entrega é cosmética e de mobilidade: não implementa projéteis, dano, efeitos de combate ou aplicação de status.
- A vassoura ativa o voo vanilla do jogador; ainda não cria uma entidade montável com assento, física própria ou animação de cavalgada.
- A preparação usa a pose vanilla de arco por 20 ticks; não é um rig próprio com keyframes editáveis.
- A conversão de `.bbmodel` preserva cubos, UVs e rotações de um eixo por cubo. Rotações compostas, elementos não-cubo e rigs animados podem exigir ajuste manual.
- O build completo ainda não foi executado com sucesso: o ambiente em que o projeto foi revisado não alcançava `maven.fabricmc.net` nem os servidores da Mojang. Veja `docs/RELATORIO_CORRECOES.md`.
