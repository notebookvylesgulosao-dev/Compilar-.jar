package com.wandryhp;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Cliente -> servidor: botão esquerdo com uma varinha na mão (ataque base). */
public record BaseAttackPayload() implements class_8710 {
    public static final class_8710.class_9154<BaseAttackPayload> ID = new class_8710.class_9154<>(WandryHP.id("base_attack"));
    public static final class_9139<class_9129, BaseAttackPayload> CODEC = class_9139.method_56431(new BaseAttackPayload());
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
