package com.wandryhp.client;

import com.wandryhp.BaseAttackPayload;
import com.wandryhp.BroomEntity;
import com.wandryhp.BroomInputPayload;
import com.wandryhp.MagicWandItem;
import com.wandryhp.WandryHP;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.minecraft.class_304;
import net.minecraft.class_315;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class WandryHPClient implements ClientModInitializer {
    private static class_304 wheelKey;
    private static int lastBroomFlags;

    @Override public void onInitializeClient() {
        wheelKey = KeyBindingHelper.registerKeyBinding(new class_304("key.wandry_hp.spell_wheel", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, "category.wandry_hp"));

        EntityRendererRegistry.register(WandryHP.SPELL_PROJECTILE, SpellProjectileRenderer::new);
        EntityRendererRegistry.register(WandryHP.BROOM, BroomRenderer::new);

        // botão esquerdo com varinha = ataque base (no lugar de quebrar bloco/bater)
        ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
            if (client.field_1755 == null && player.method_6047().method_7909() instanceof MagicWandItem) {
                ClientPlayNetworking.send(new BaseAttackPayload());
                return true;
            }
            return false;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (wheelKey.method_1436()) if (client.field_1755 == null) client.method_1507(new SpellWheelScreen());

            // controles da vassoura: W/A/S/D, Espaço sobe, Ctrl (tecla de correr) desce
            int flags = 0;
            if (client.field_1724 != null && client.field_1724.method_5854() instanceof BroomEntity) {
                class_315 o = client.field_1690;
                if (o.field_1894.method_1434()) flags |= BroomEntity.FORWARD;
                if (o.field_1881.method_1434()) flags |= BroomEntity.BACK;
                if (o.field_1913.method_1434()) flags |= BroomEntity.LEFT;
                if (o.field_1849.method_1434()) flags |= BroomEntity.RIGHT;
                if (o.field_1903.method_1434()) flags |= BroomEntity.UP;
                if (o.field_1867.method_1434()) flags |= BroomEntity.DOWN;
            }
            if (flags != lastBroomFlags) {
                lastBroomFlags = flags;
                if (client.field_1724 != null) ClientPlayNetworking.send(new BroomInputPayload(flags));
            }
        });
    }
}
