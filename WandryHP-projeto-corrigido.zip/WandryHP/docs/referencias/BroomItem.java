package com.wandryhp;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;

/** Ao usar, invoca a vassoura como entidade e monta nela. O item só volta ao desmontar ou recuperar. */
public final class BroomItem extends class_1792 {
    public BroomItem(class_1793 settings) { super(settings); }

    @Override public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (user.method_5765()) return class_1269.field_5811;
        if (!world.field_9236) {
            BroomEntity broom = new BroomEntity(WandryHP.BROOM, world);
            broom.method_5808(user.method_23317(), user.method_23318() + 0.2, user.method_23321(), user.method_36454(), 0f);
            world.method_8649(broom);
            user.method_5804(broom);
            if (!user.method_31549().field_7477) user.method_5998(hand).method_7934(1);
        }
        return class_1269.field_5812;
    }
}
