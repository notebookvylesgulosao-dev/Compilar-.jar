package com.wandryhp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Botão direito: lança o feitiço selecionado na roda (projétil com rastro do feitiço + rastro da varinha).
 * Botão esquerdo: ataque base (prop da varinha com rastro da varinha).
 */
public final class MagicWandItem extends class_1792 {
    public enum Spell {
        AVADA_KEDAVRA("Avada Kedavra", 0x22C55E),
        CORINFICUS("Corinficus", 0xE53935),
        CRUCIO("Crucio", 0xFF1111),
        EXPELLIARMUS("Expelliarmus", 0xF2F2F2),
        IMPERIUS("Imperius", 0xFFC93C),
        PETRIFICUS_TOTALIS("Petrificus Totalis", 0x9E9E9E),
        SECTUMSEMPRA("Sectumsempra", 0x8B2BE2);
        public final String displayName;
        public final int color;
        Spell(String displayName, int color) { this.displayName = displayName; this.color = color; }
    }

    /** Estilo de rastro da varinha e índice do prop de ataque base (ordem de QuadModel.NAMES). */
    public enum Style {
        AMETHYST(7), BONE(8), CELESTIAL(9), DRAGON(10),
        EMERALD(7),  // sem prop próprio: usa o do Amethyst (teste)
        MAGMA(10),   // sem prop próprio: usa o do Dragon (teste)
        WIDOW(11);
        public final int propModel;
        Style(int propModel) { this.propModel = propModel; }
    }

    private static final String SPELL_KEY = "wandry_spell";
    private static final int BASE_ATTACK_COOLDOWN_TICKS = 10;
    private static final Map<UUID, Long> LAST_BASE_ATTACK = new HashMap<>();

    private final Spell defaultSpell;
    private final Style style;

    public MagicWandItem(Spell defaultSpell, Style style, class_1793 settings) {
        super(settings);
        this.defaultSpell = defaultSpell;
        this.style = style;
    }

    public Spell spell() { return defaultSpell; }
    public Style style() { return style; }

    /** Feitiço escolhido na roda para esta varinha (ou o padrão dela). */
    public static Spell selectedSpell(class_1799 stack) {
        Spell fallback = stack.method_7909() instanceof MagicWandItem wand ? wand.defaultSpell : Spell.EXPELLIARMUS;
        class_9279 data = stack.method_57824(class_9334.field_49628);
        if (data != null) {
            class_2487 nbt = data.method_57461();
            if (nbt.method_10545(SPELL_KEY)) {
                int i = nbt.method_10550(SPELL_KEY);
                if (i >= 0 && i < Spell.values().length) return Spell.values()[i];
            }
        }
        return fallback;
    }

    public static void setSelectedSpell(class_1799 stack, Spell spell) {
        class_9279.method_57452(class_9334.field_49628, stack, nbt -> nbt.method_10569(SPELL_KEY, spell.ordinal()));
    }

    @Override public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        Spell spell = selectedSpell(stack);
        if (!world.field_9236 && world instanceof class_3218 serverWorld) {
            SpellProjectileEntity.launch(serverWorld, user, spell.ordinal(), spell.ordinal(), style.ordinal());
            serverWorld.method_8396(null, user.method_24515(), class_3417.field_14858, class_3419.field_15248, .7f, 1.15f);
        }
        int cooldown = switch (spell) {
            case AVADA_KEDAVRA, SECTUMSEMPRA -> 600;
            case CORINFICUS, IMPERIUS -> 400;
            case CRUCIO -> 300;
            case EXPELLIARMUS, PETRIFICUS_TOTALIS -> 200;
        };
        user.method_7357().method_62835(stack, cooldown);
        return class_1269.field_5812;
    }

    /** Chamado pelo servidor quando o cliente clica com o botão esquerdo segurando uma varinha. */
    public static void baseAttack(class_3222 player) {
        class_1799 stack = player.method_6047();
        if (!(stack.method_7909() instanceof MagicWandItem wand)) return;
        class_3218 world = player.method_51469();
        long now = world.method_8510();
        Long last = LAST_BASE_ATTACK.get(player.method_5667());
        if (last != null && now - last < BASE_ATTACK_COOLDOWN_TICKS) return;
        LAST_BASE_ATTACK.put(player.method_5667(), now);
        player.method_23667(class_1268.field_5808, true);
        SpellProjectileEntity.launch(world, player, wand.style.propModel, -1, wand.style.ordinal());
        world.method_8396(null, player.method_24515(), class_3417.field_14858, class_3419.field_15248, .4f, 1.7f);
    }
}
