package com.wandryhp.client;

import com.wandryhp.BroomEntity;
import com.wandryhp.MagicWandItem;
import com.wandryhp.SelectSpellPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/** Roda redonda com os sete feitiços. Clique (ou teclas 1-7) escolhe o feitiço da varinha na mão. */
public final class SpellWheelScreen extends class_437 {
    private static final MagicWandItem.Spell[] SPELLS = MagicWandItem.Spell.values();
    private static final int N = SPELLS.length;
    private static final double STEP = Math.PI * 2 / N;
    private static final int INNER = 36, OUTER = 96;

    public SpellWheelScreen() { super(class_2561.method_43471("screen.wandry_hp.wheel")); }

    /** Setor sob o ponto (dx, dy) relativo ao centro: 0 no topo, sentido horário; -1 fora do anel. */
    private static int sectorAt(double dx, double dy) {
        double r = Math.sqrt(dx * dx + dy * dy);
        if (r < INNER || r > OUTER) return -1;
        return (int) (angle(dx, dy) / STEP) % N;
    }

    private static double angle(double dx, double dy) {
        double a = Math.atan2(dx, -dy);
        return a < 0 ? a + Math.PI * 2 : a;
    }

    private class_1799 heldWand() {
        if (field_22787 == null || field_22787.field_1724 == null) return class_1799.field_8037;
        class_1799 main = field_22787.field_1724.method_6047();
        if (main.method_7909() instanceof MagicWandItem) return main;
        class_1799 off = field_22787.field_1724.method_6079();
        return off.method_7909() instanceof MagicWandItem ? off : class_1799.field_8037;
    }

    private static int colorAt(double dx, double dy, int hover, int selected) {
        double r = Math.sqrt(dx * dx + dy * dy);
        if (r < INNER || r > OUTER) return 0;
        double a = angle(dx, dy);
        int idx = (int) (a / STEP) % N;
        double frac = a - idx * STEP;
        if (Math.min(frac, STEP - frac) * r < 1.5) return 0; // vão entre setores
        if (idx == selected && r > OUTER - 3) return 0xFFFFFFFF;
        int alpha = idx == selected ? 0xE6 : idx == hover ? 0xCC : 0x80;
        return (alpha << 24) | SPELLS[idx].color;
    }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int cx = field_22789 / 2, cy = field_22790 / 2;
        class_1799 wand = heldWand();
        int selected = wand.method_7960() ? -1 : MagicWandItem.selectedSpell(wand).ordinal();
        int hover = sectorAt(mouseX - cx, mouseY - cy);

        for (int y = -OUTER; y <= OUTER; y += 2) {
            int runStart = 0, runColor = 0;
            for (int x = -OUTER; x <= OUTER + 2; x += 2) {
                int color = x <= OUTER ? colorAt(x + 1, y + 1, hover, selected) : 0;
                if (color != runColor) {
                    if (runColor != 0) context.method_25294(cx + runStart, cy + y, cx + x, cy + y + 2, runColor);
                    runStart = x;
                    runColor = color;
                }
            }
        }

        double ringMid = (INNER + OUTER) / 2.0;
        for (int i = 0; i < N; i++) {
            double mid = (i + 0.5) * STEP;
            double sx = Math.sin(mid), sy = -Math.cos(mid);
            context.method_25300(field_22793, String.valueOf(i + 1),
                cx + (int) (sx * ringMid), cy + (int) (sy * ringMid) - 4, 0xFFFFFF);
            String name = SPELLS[i].displayName;
            int lx = cx + (int) (sx * (OUTER + 12)), ly = cy + (int) (sy * (OUTER + 12)) - 4;
            int color = i == selected ? 0xFFFFFF : 0xC8C8C8;
            if (sx > 0.35) context.method_25303(field_22793, name, lx, ly, color);
            else if (sx < -0.35) context.method_25303(field_22793, name, lx - field_22793.method_1727(name), ly, color);
            else context.method_25300(field_22793, name, lx, ly, color);
        }

        context.method_25300(field_22793, "Roda de Feitiços", cx, cy - OUTER - 30, 0xD9B8FF);
        String bottom = wand.method_7960() ? "Segure uma varinha para escolher o feitiço"
            : hover >= 0 ? SPELLS[hover].displayName : "Feitiço atual: " + SPELLS[selected].displayName;
        context.method_25300(field_22793, bottom, cx, cy + OUTER + 30, 0xFFFFFF);
    }

    @Override public boolean method_25402(double mouseX, double mouseY, int button) {
        int sector = sectorAt(mouseX - field_22789 / 2.0, mouseY - field_22790 / 2.0);
        if (button == 0 && sector >= 0) { select(sector); return true; }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode >= GLFW.GLFW_KEY_1 && keyCode < GLFW.GLFW_KEY_1 + N) { select(keyCode - GLFW.GLFW_KEY_1); return true; }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void select(int index) {
        if (!heldWand().method_7960()) ClientPlayNetworking.send(new SelectSpellPayload(index));
        method_25419();
    }

    @Override public boolean method_25421() { return false; }
}
