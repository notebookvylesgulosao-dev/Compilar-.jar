package com.wandryhp;

import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2392;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5743;
import net.minecraft.particle.*;

/**
 * Projétil visual: modelo original (feitiço ou prop de ataque base) + rastro do feitiço + rastro da varinha.
 * Só colide e some; não causa dano nem efeitos.
 */
public final class SpellProjectileEntity extends class_1676 {
    private static final class_2940<Integer> MODEL = class_2945.method_12791(SpellProjectileEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> SPELL = class_2945.method_12791(SpellProjectileEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> STYLE = class_2945.method_12791(SpellProjectileEntity.class, class_2943.field_13327);
    private static final int LIFETIME_TICKS = 50;
    private static final double SPEED = 1.4;

    public SpellProjectileEntity(class_1299<? extends SpellProjectileEntity> type, class_1937 world) {
        super(type, world);
        method_5875(true);
    }

    /** model: 0-6 = feitiços, 7-11 = props. spell: índice do feitiço ou -1 (ataque base). style: ordinal de Style. */
    public static void launch(class_3218 world, class_1657 caster, int model, int spell, int style) {
        SpellProjectileEntity p = new SpellProjectileEntity(WandryHP.SPELL_PROJECTILE, world);
        class_243 dir = caster.method_5828(1f).method_1029();
        class_243 pos = caster.method_33571().method_1019(dir.method_1021(0.8)).method_1023(0, 0.15, 0);
        float yaw = (float) (class_3532.method_15349(dir.field_1352, dir.field_1350) * 57.29578);
        float pitch = (float) (class_3532.method_15349(dir.field_1351, Math.sqrt(dir.field_1352 * dir.field_1352 + dir.field_1350 * dir.field_1350)) * 57.29578);
        p.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, yaw, pitch);
        p.method_7432(caster);
        p.method_18799(dir.method_1021(SPEED));
        p.field_6011.method_12778(MODEL, model);
        p.field_6011.method_12778(SPELL, spell);
        p.field_6011.method_12778(STYLE, style);
        world.method_8649(p);
    }

    public int modelIndex() { return field_6011.method_12789(MODEL); }

    @Override protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(MODEL, 0);
        builder.method_56912(SPELL, -1);
        builder.method_56912(STYLE, 0);
    }

    @Override protected void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("Model", field_6011.method_12789(MODEL));
        nbt.method_10569("Spell", field_6011.method_12789(SPELL));
        nbt.method_10569("Style", field_6011.method_12789(STYLE));
    }

    @Override protected void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        field_6011.method_12778(MODEL, nbt.method_10550("Model"));
        field_6011.method_12778(SPELL, nbt.method_10550("Spell"));
        field_6011.method_12778(STYLE, nbt.method_10550("Style"));
    }

    @Override public void method_5773() {
        super.method_5773();
        class_1937 world = method_37908();
        if (!world.field_9236) {
            if (field_6012 > LIFETIME_TICKS) { method_31472(); return; }
            class_239 hit = class_1675.method_49997(this, this::method_26958);
            if (hit.method_17783() != class_239.class_240.field_1333) method_59860(hit);
            if (method_31481()) return;
        }
        class_243 v = method_18798();
        method_5814(method_23317() + v.field_1352, method_23318() + v.field_1351, method_23321() + v.field_1350);
        field_5982 = method_36454();
        field_6004 = method_36455();
        method_36456((float) (class_3532.method_15349(v.field_1352, v.field_1350) * 57.29578));
        method_36457((float) (class_3532.method_15349(v.field_1351, Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350)) * 57.29578));
        if (world.field_9236) spawnTrail();
    }

    @Override protected void method_7454(class_3966 hit) {
        super.method_7454(hit);
        if (!method_37908().field_9236) method_31472();
    }

    @Override protected void method_24920(class_3965 hit) {
        super.method_24920(hit);
        if (!method_37908().field_9236) method_31472();
    }

    // ------------------------------------------------------------------ rastros (client)

    private void spawnTrail() {
        class_243 c = method_19538().method_1031(0, method_17682() / 2, 0);
        int spell = field_6011.method_12789(SPELL);
        if (spell >= 0 && spell < MagicWandItem.Spell.values().length) spellTrail(MagicWandItem.Spell.values()[spell], c);
        wandTrail(MagicWandItem.Style.values()[class_3532.method_15340(field_6011.method_12789(STYLE), 0, MagicWandItem.Style.values().length - 1)], c);
    }

    private double jitter(double s) { return field_5974.method_43059() * s; }

    private void dust(int rgb, float scale, class_243 c, double spread) {
        method_37908().method_8406(new class_2390(rgb, scale), c.field_1352 + jitter(spread), c.field_1351 + jitter(spread), c.field_1350 + jitter(spread), 0, 0, 0);
    }

    private void puff(class_2394 effect, class_243 c, double spread, double vx, double vy, double vz) {
        method_37908().method_8406(effect, c.field_1352 + jitter(spread), c.field_1351 + jitter(spread), c.field_1350 + jitter(spread), vx, vy, vz);
    }

    private void spellTrail(MagicWandItem.Spell spell, class_243 c) {
        switch (spell) {
            case AVADA_KEDAVRA -> { // verde, fumaça e partículas verdes
                dust(0x1FE04A, 1.0f, c, 0.12);
                dust(0x1FE04A, 0.8f, c, 0.12);
                dust(0x0B5E20, 2.0f, c, 0.15);
                puff(class_2398.field_11251, c, 0.1, 0, 0.01, 0);
            }
            case CORINFICUS -> { // vermelho, partículas vermelhas e energia explosiva
                dust(0xFF2A2A, 1.1f, c, 0.12);
                dust(0xFF2A2A, 0.8f, c, 0.15);
                if (field_5974.method_43048(5) == 0) puff(class_2398.field_11236, c, 0.1, 0.4, 0, 0);
            }
            case CRUCIO -> { // vermelho intenso, partículas que se dissipam
                for (int i = 0; i < 3; i++)
                    method_37908().method_8406(new class_5743(0xFF0000, 0x1A0000, 1.4f),
                        c.field_1352 + jitter(0.12), c.field_1351 + jitter(0.12), c.field_1350 + jitter(0.12), 0, 0, 0);
            }
            case EXPELLIARMUS -> { // branco, partículas luminosas
                puff(class_2398.field_11207, c, 0.08, 0, 0, 0);
                dust(0xFFFFFF, 0.8f, c, 0.1);
            }
            case IMPERIUS -> { // amarelo e dourado, partículas brilhantes
                dust(0xFFD84A, 1.0f, c, 0.12);
                dust(0xFFF04A, 0.8f, c, 0.12);
                puff(class_2398.field_29642, c, 0.12, 0, 0, 0);
            }
            case PETRIFICUS_TOTALIS -> { // cinza, partículas acinzentadas
                dust(0x9E9E9E, 1.1f, c, 0.12);
                dust(0x7A7A7A, 0.9f, c, 0.12);
                puff(class_2398.field_22247, c, 0.12, 0, 0, 0);
            }
            case SECTUMSEMPRA -> { // roxo, partículas violetas
                dust(0x8B2BE2, 1.1f, c, 0.12);
                dust(0xB35CFF, 0.8f, c, 0.12);
                puff(class_2398.field_11249, c, 0.1, 0, 0, 0);
            }
        }
    }

    private void wandTrail(MagicWandItem.Style style, class_243 c) {
        switch (style) {
            case AMETHYST -> { // cristais roxos
                puff(new class_2392(class_2398.field_11218, new class_1799(class_1802.field_27063)), c, 0.1, 0, 0, 0);
                dust(0x9B59F0, 0.6f, c, 0.1);
            }
            case BONE -> { // fragmentos brancos e cinzas de ossos
                puff(new class_2392(class_2398.field_11218, new class_1799(class_1802.field_8324)), c, 0.1, 0, 0, 0);
                if (field_5974.method_43056()) puff(class_2398.field_22247, c, 0.1, 0, 0, 0);
            }
            case CELESTIAL -> { // estrelas brancas, douradas e azuis
                puff(class_2398.field_11207, c, 0.1, 0, 0, 0);
                dust(field_5974.method_43056() ? 0xFFD700 : 0x55AAFF, 0.7f, c, 0.1);
            }
            case DRAGON -> { // pequenas chamas verdes e laranjas
                puff(class_2398.field_27783, c, 0.08, 0, 0.01, 0);
                dust(0x33FF55, 0.6f, c, 0.1);
            }
            case EMERALD -> { // cristais verde-esmeralda
                puff(new class_2392(class_2398.field_11218, new class_1799(class_1802.field_8687)), c, 0.1, 0, 0, 0);
                dust(0x2ECC71, 0.6f, c, 0.1);
            }
            case MAGMA -> { // brasas vermelhas, laranjas e amarelas
                int[] embers = { 0xFF2A00, 0xFF8C00, 0xFFD21E };
                dust(embers[field_5974.method_43048(3)], 0.7f, c, 0.12);
                if (field_5974.method_43048(4) == 0) puff(class_2398.field_11239, c, 0.1, 0, 0, 0);
            }
            case WIDOW -> { // fios e partículas pretas, brancas, cinzas e vermelhas
                int[] colors = { 0x111111, 0xFFFFFF, 0x888888, 0xAA0000 };
                dust(colors[field_5974.method_43048(4)], 0.6f, c, 0.12);
                if (field_5974.method_43056()) puff(new class_2392(class_2398.field_11218, new class_1799(class_1802.field_8276)), c, 0.1, 0, 0, 0);
            }
        }
    }
}
