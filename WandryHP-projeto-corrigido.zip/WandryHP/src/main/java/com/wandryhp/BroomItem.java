package com.wandryhp;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Voo mágico sem combate; ativa/desativa o voo vanilla em sobrevivência. */
public final class BroomItem extends Item {
    private static final Set<UUID> ACTIVE=ConcurrentHashMap.newKeySet();
    public BroomItem(Settings settings){super(settings);}
    @Override public ActionResult use(World world,PlayerEntity user,Hand hand){
        if(!world.isClient && user instanceof ServerPlayerEntity player){
            UUID id=player.getUuid();
            if(ACTIVE.remove(id)){
                if(!player.isCreative() && !player.isSpectator()){player.getAbilities().flying=false;player.getAbilities().allowFlying=false;}
                player.getAbilities().setFlySpeed(0.05f); player.sendAbilitiesUpdate(); player.sendMessage(net.minecraft.text.Text.literal("Vassoura guardada."),true);
            }else{
                ACTIVE.add(id); player.getAbilities().allowFlying=true; player.getAbilities().flying=true;
                player.getAbilities().setFlySpeed(0.075f); player.sendAbilitiesUpdate();
                player.sendMessage(net.minecraft.text.Text.literal("Voo mágico ativado — use a vassoura novamente para desativar."),true);
            }
            player.getItemCooldownManager().set(user.getStackInHand(hand),10);
        }
        return ActionResult.SUCCESS;
    }
    public static boolean isActive(UUID id){return ACTIVE.contains(id);}
    public static void clear(ServerPlayerEntity player){
        if(ACTIVE.remove(player.getUuid()) && !player.isCreative() && !player.isSpectator()){
            player.getAbilities().flying=false; player.getAbilities().allowFlying=false; player.getAbilities().setFlySpeed(0.05f);
            player.sendAbilitiesUpdate();
        }
    }
    public static void clearOnDisconnect(ServerPlayerEntity player){
        if(ACTIVE.remove(player.getUuid()) && !player.isCreative() && !player.isSpectator()){
            player.getAbilities().flying=false; player.getAbilities().allowFlying=false; player.getAbilities().setFlySpeed(0.05f);
        }
    }
}
