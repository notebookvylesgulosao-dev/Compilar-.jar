package com.wandryhp;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record SpellSelectionPayload(int index) implements CustomPayload {
    public static final Id<SpellSelectionPayload> ID = new Id<>(Identifier.of(WandryHP.MOD_ID,"spell_selection"));
    public static final PacketCodec<RegistryByteBuf,SpellSelectionPayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT,SpellSelectionPayload::index,SpellSelectionPayload::new);
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
