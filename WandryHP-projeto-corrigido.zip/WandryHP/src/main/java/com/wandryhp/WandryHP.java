package com.wandryhp;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class WandryHP implements ModInitializer {
    public static final String MOD_ID="wandry_hp";
    private static final Map<UUID,Integer> SELECTED=new ConcurrentHashMap<>();
    public static final Item AMETHYST_WAND=wand("amethyst_wand",MagicWandItem.Spell.EXPELLIARMUS,MagicWandItem.Style.AMETHYST);
    public static final Item BONE_WAND=wand("bone_wand",MagicWandItem.Spell.CRUCIO,MagicWandItem.Style.BONE);
    public static final Item CELESTIAL_WAND=wand("celestial_wand",MagicWandItem.Spell.IMPERIUS,MagicWandItem.Style.CELESTIAL);
    public static final Item DRAGON_WAND=wand("dragon_wand",MagicWandItem.Spell.CONFRINGO,MagicWandItem.Style.DRAGON);
    public static final Item EMERALD_WAND=wand("emerald_wand",MagicWandItem.Spell.PETRIFICUS_TOTALIS,MagicWandItem.Style.EMERALD);
    public static final Item MAGMA_WAND=wand("magma_wand",MagicWandItem.Spell.SECTUMSEMPRA,MagicWandItem.Style.MAGMA);
    public static final Item WIDOW_WAND=wand("widow_wand",MagicWandItem.Spell.AVADA_KEDAVRA,MagicWandItem.Style.WIDOW);
    public static final Item AMETHYST_PROP=prop("amethyst_prop",0xA65CFF,0xD9A7FF);
    public static final Item BONE_PROP=prop("bone_prop",0xF0EEE8,0xA9A9A9);
    public static final Item CELESTIAL_PROP=prop("celestial_prop",0x42D9D0,0xB8FFFF);
    public static final Item DRAGON_PROP=prop("dragon_prop",0xF05A24,0xFFB02E);
    public static final Item MAGMA_PROP=prop("magma_prop",0xF23A13,0xFF9A20);
    public static final Item WIDOW_PROP=prop("widow_prop",0xD0D0D0,0xA40024);
    public static final Item WITCH_BROOM=register("witch_broom",BroomItem::new,1);
    public static final Item WITCH_HAT=register("witch_hat",Item::new,1);
    public static final Item SPELL_SCROLL=register("spell_scroll",s->new Item(s.maxCount(16)),16);
    public static final RegistryKey<ItemGroup> GROUP_KEY=RegistryKey.of(RegistryKeys.ITEM_GROUP,id("main"));
    public static final ItemGroup GROUP=FabricItemGroup.builder().icon(()->new ItemStack(AMETHYST_WAND))
            .displayName(Text.translatable("itemGroup.wandry_hp.main")).build();
    private static Item wand(String name,MagicWandItem.Spell spell,MagicWandItem.Style style){return register(name,s->new MagicWandItem(spell,style,s),1);}
    private static Item prop(String name,int color,int accent){return register(name,s->new PropItem(color,accent,s),1);}
    private static Item register(String path,Function<Item.Settings,Item> factory,int count){
        RegistryKey<Item> key=RegistryKey.of(RegistryKeys.ITEM,id(path));
        return Registry.register(Registries.ITEM,key,factory.apply(new Item.Settings().registryKey(key).maxCount(count)));
    }
    public static Identifier id(String path){return Identifier.of(MOD_ID,path);}
    public static void setSelectedSpell(UUID player,int index){SELECTED.put(player,Math.floorMod(index,MagicWandItem.Spell.values().length));}
    public static int getSelectedSpell(UUID player,int fallback){return SELECTED.getOrDefault(player,fallback);}
    @Override public void onInitialize(){
        Registry.register(Registries.ITEM_GROUP,GROUP_KEY,GROUP);
        ItemGroupEvents.modifyEntriesEvent(GROUP_KEY).register(entries->{
            entries.add(AMETHYST_WAND);entries.add(BONE_WAND);entries.add(CELESTIAL_WAND);entries.add(DRAGON_WAND);entries.add(EMERALD_WAND);entries.add(MAGMA_WAND);entries.add(WIDOW_WAND);
            entries.add(AMETHYST_PROP);entries.add(BONE_PROP);entries.add(CELESTIAL_PROP);entries.add(DRAGON_PROP);entries.add(MAGMA_PROP);entries.add(WIDOW_PROP);
            entries.add(WITCH_BROOM);entries.add(WITCH_HAT);entries.add(SPELL_SCROLL);
        });
        PayloadTypeRegistry.playC2S().register(SpellSelectionPayload.ID,SpellSelectionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SpellSelectionPayload.ID,(payload,context)->context.server().execute(()->setSelectedSpell(context.player().getUuid(),payload.index())));
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->BroomItem.clearOnDisconnect(handler.player));
    }
}
