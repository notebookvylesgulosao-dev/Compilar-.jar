package com.wandryhp.client;

import com.wandryhp.SpellSelectionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class WandryHPClient implements ClientModInitializer {
    private static KeyBinding wheelKey;
    @Override public void onInitializeClient(){
        wheelKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.wandry_hp.spell_wheel",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_G,"category.wandry_hp"));
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            while(wheelKey.wasPressed()) if(client.player!=null && client.currentScreen==null) client.setScreen(new SpellWheelScreen());
        });
    }
    static void commit(int index){net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(new SpellSelectionPayload(index));}
}
