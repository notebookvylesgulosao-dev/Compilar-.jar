package com.wandryhp;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/** Props ativáveis: efeitos de manifestação exclusivamente visuais. */
public final class PropItem extends Item {
    private final int color; private final int accent;
    public PropItem(int color,int accent,Settings settings){super(settings);this.color=color;this.accent=accent;}
    @Override public ActionResult use(World world,PlayerEntity user,Hand hand){
        if(!world.isClient && world instanceof ServerWorld server){
            double x=user.getX(), y=user.getBodyY(.72), z=user.getZ();
            for(int i=0;i<28;i++){
                double a=Math.PI*2*i/28.0; double radius=.45+(.12*Math.sin(i*1.7));
                double px=x+Math.cos(a)*radius, pz=z+Math.sin(a)*radius;
                server.spawnParticles(new DustParticleEffect((i%3==0)?accent:color,.8f),px,y+MathHelper.sin((float)a)*.22,pz,1,.012,.025,.012,.002);
            }
            server.spawnParticles(new DustParticleEffect(color,1.35f),x,y+.25,z,16,.18,.22,.18,.012);
            user.getItemCooldownManager().set(user.getStackInHand(hand),18);
        }
        user.swingHand(hand); return ActionResult.SUCCESS;
    }
}
