import json, base64, os, glob, math
from pathlib import Path
src=Path('/mnt/data/wandry_src'); root=Path('/mnt/data/WandryHP/src/main/resources/assets/wandry_hp')
(root/'models/item').mkdir(parents=True,exist_ok=True); (root/'textures/item').mkdir(parents=True,exist_ok=True); (root/'textures/entity').mkdir(parents=True,exist_ok=True)

def safe(s):
    s=s.lower().replace(' ','_').replace('-','_')
    return ''.join(c for c in s if c.isalnum() or c=='_')

def export(f, outname, texture_dir='item', make_model=True):
    d=json.load(open(f,encoding='utf8'))
    textures=d.get('textures',[])
    texnames=[]
    for i,t in enumerate(textures):
        name=safe(t.get('name') or f'{outname}_{i}')
        # Stable per-model texture naming, don't overwrite shared texture names.
        texpath=f'{outname}_{i}.png' if len(textures)>1 else f'{outname}_0.png'
        raw=t.get('source','')
        if raw.startswith('data:image') and ',' in raw:
            data=base64.b64decode(raw.split(',',1)[1])
            (root/f'textures/{texture_dir}/{texpath}').write_bytes(data)
        texnames.append(f'wandry_hp:{texture_dir}/{Path(texpath).stem}')
    if not make_model: return
    texmap={f'tex{i}':v for i,v in enumerate(texnames)}
    elements=[]
    face_names=('north','east','south','west','up','down')
    for el in d.get('elements',[]):
        if el.get('type','cube')!='cube' or el.get('export') is False: continue
        e={'from':el['from'],'to':el['to'],'faces':{}}
        rot=el.get('rotation') or [0,0,0]
        nonzero=[(i,float(v)) for i,v in enumerate(rot) if abs(float(v))>0.001]
        if nonzero:
            axis_i,angle=max(nonzero,key=lambda x:abs(x[1]))
            axis=('x','y','z')[axis_i]
            e['rotation']={'origin':el.get('origin',[8,8,8]),'axis':axis,'angle':round(angle,4),'rescale':bool(el.get('rescale',False))}
        for face,fd in (el.get('faces') or {}).items():
            if not fd or fd.get('texture') is None: continue
            ti=int(fd.get('texture',0))
            if ti<0 or ti>=len(texnames): continue
            uv=fd.get('uv')
            if uv is None: continue
            e['faces'][face]={'uv':uv,'texture':f'#tex{ti}','rotation':int(fd.get('rotation',0))}
        if e['faces']: elements.append(e)
    model={'credit':'Converted from the supplied Blockbench project; original .bbmodel is retained in /blockbench.','textures':texmap,'elements':elements,
      'display':{
        'thirdperson_righthand':{'rotation':[0,90,0],'translation':[0,2,1],'scale':[0.75,0.75,0.75]},
        'thirdperson_lefthand':{'rotation':[0,90,0],'translation':[0,2,1],'scale':[0.75,0.75,0.75]},
        'firstperson_righthand':{'rotation':[0,-90,25],'translation':[1.13,3.2,1.13],'scale':[0.68,0.68,0.68]},
        'firstperson_lefthand':{'rotation':[0,90,-25],'translation':[1.13,3.2,1.13],'scale':[0.68,0.68,0.68]},
        'gui':{'rotation':[25,135,0],'scale':[0.8,0.8,0.8]},'ground':{'translation':[0,2,0],'scale':[0.5,0.5,0.5]},'fixed':{'rotation':[0,90,0],'scale':[0.8,0.8,0.8]}
      }}
    (root/f'models/item/{outname}.json').write_text(json.dumps(model,ensure_ascii=False,indent=2),encoding='utf8')

# Updated wand models: the six new files; Bone retains the supplied existing model.
for f in glob.glob(str(src/'varinha novos modelos'/'*.bbmodel')):
    stem=Path(f).stem
    names={'amethyst-rod':'amethyst_wand','celestial_wand':'celestial_wand','dragon-rod':'dragon_wand','emerald_wand_refined':'emerald_wand','magma_wand':'magma_wand','widow-rod':'widow_wand'}
    export(f,names[stem])
# All prop models.
for f in glob.glob(str(src/'prop base'/'*.bbmodel')):
    stem=Path(f).stem
    names={'amethyst-prop':'amethyst_prop','bone_prop':'bone_prop','celestial_prop':'celestial_prop','dragon-prop':'dragon_prop','magma_prop':'magma_prop','widow-prop':'widow_prop'}
    export(f,names[stem])
# Projectile source models and their textures; these are also emitted as item-compatible model JSON
# for use by the projectile renderer in the next stage.
projectiles={'WandryHP Red':'confringo','WandryHPAmarelo':'imperius','WandryHPCinza':'petrificus_totalis','WandryHPTurquesa':'corinficus','WandryHpVerde':'avada_kedavra'}
for f in glob.glob(str(src/'projeteis novos modelos'/'*.bbmodel')):
    export(f,projectiles[Path(f).stem],texture_dir='entity')
