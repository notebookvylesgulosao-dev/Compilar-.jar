package com.wandryhp.client;

import com.wandryhp.SpellProjectileEntity;
import com.wandryhp.WandryHP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Renderiza o núcleo em 3D e vários itens Minecraft como rastro, sem criar drops. */
public final class SpellProjectileRenderer extends EntityRenderer<SpellProjectileEntity> {
    private static final Item[] CORES = {Items.EMERALD, Items.FIRE_CHARGE, Items.REDSTONE, Items.AMETHYST_SHARD, Items.GOLD_NUGGET, Items.IRON_NUGGET, Items.PURPLE_DYE};
    private static final Item[][] TRAILS = {
        {Items.EMERALD, Items.LIME_DYE, Items.MOSS_BLOCK, Items.SLIME_BALL},
        {Items.BLAZE_POWDER, Items.FIRE_CHARGE, Items.MAGMA_CREAM, Items.ORANGE_DYE},
        {Items.REDSTONE, Items.RED_DYE, Items.NETHER_WART, Items.FIRE_CORAL},
        {Items.QUARTZ, Items.WHITE_DYE, Items.AMETHYST_SHARD, Items.GLOWSTONE_DUST},
        {Items.GOLD_NUGGET, Items.HONEYCOMB, Items.YELLOW_DYE, Items.GLOWSTONE_DUST},
        {Items.IRON_NUGGET, Items.GRAY_DYE, Items.STONE, Items.INK_SAC},
        {Items.AMETHYST_SHARD, Items.PURPLE_DYE, Items.CHORUS_FRUIT, Items.PURPLE_GLAZED_TERRACOTTA}
    };
    public SpellProjectileRenderer(EntityRendererFactory.Context context) { super(context); }
    @Override public void render(SpellProjectileEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertices, int light) {
        ItemRenderer renderer = MinecraftClient.getInstance().getItemRenderer();
        int spell = Math.floorMod(entity.getSpellIndex(), CORES.length);
        float age = entity.getVisualAge() + tickDelta;
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(entity.getPitch()));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(age * 13.0f));
        float pulse = 0.82f + 0.12f * MathHelper.sin(age * 0.45f);
        matrices.scale(pulse, pulse, pulse);
        renderer.renderItem(new ItemStack(CORES[spell]), ModelTransformationMode.FIXED, light, OverlayTexture.DEFAULT_UV, matrices, vertices, entity.getWorld(), entity.getId());
        matrices.pop();
        // Quatro pequenos itens por segmento dão a sensação de uma trilha contínua.
        Item[] trail = TRAILS[Math.floorMod(entity.getStyleIndex(), TRAILS.length)];
        for (int i = 1; i <= 12; i++) {
            float behind = i * 0.115f;
            float fade = 1.0f - i / 14.0f;
            matrices.push();
            matrices.translate(0, 0, behind);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((age * 17 + i * 47) % 360));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((i * 31) % 360));
            float size = (0.12f + (i % 3) * 0.025f) * fade;
            matrices.scale(size, size, size);
            Item item = trail[(i + (int)(age / 3)) % trail.length];
            renderer.renderItem(new ItemStack(item), ModelTransformationMode.FIXED, light, OverlayTexture.DEFAULT_UV, matrices, vertices, entity.getWorld(), entity.getId() + i);
            matrices.pop();
        }
        super.render(entity, yaw, tickDelta, matrices, vertices, light);
    }
    @Override public Identifier getTexture(SpellProjectileEntity entity) { return Identifier.of("minecraft", "textures/atlas/blocks.png"); }
}
