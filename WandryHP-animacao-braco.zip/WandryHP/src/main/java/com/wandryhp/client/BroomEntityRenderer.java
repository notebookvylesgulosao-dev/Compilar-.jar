package com.wandryhp.client;

import com.wandryhp.BroomEntity;
import com.wandryhp.WandryHP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public final class BroomEntityRenderer extends EntityRenderer<BroomEntity> {
    public BroomEntityRenderer(EntityRendererFactory.Context context) { super(context); }

    @Override
    public void render(BroomEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertices, int light) {
        matrices.push();
        // O modelo 3D da própria vassoura é reutilizado como corpo visível da montaria.
        matrices.translate(0.0, 0.12, 0.0);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
        matrices.scale(1.0f, 1.0f, 1.0f);
        ItemRenderer renderer = MinecraftClient.getInstance().getItemRenderer();
        renderer.renderItem(new ItemStack(WandryHP.WITCH_BROOM), ModelTransformationMode.FIXED,
                light, OverlayTexture.DEFAULT_UV, matrices, vertices, entity.getWorld(), entity.getId());
        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertices, light);
    }

    @Override
    public Identifier getTexture(BroomEntity entity) {
        return Identifier.of(WandryHP.MOD_ID, "textures/entity/witch_broom.png");
    }
}
