package com.wandryhp;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.consume.UseAction;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Varinha mágica: preparação visual de 20 ticks e disparo de projétil puramente visual, sem dano. */
public final class MagicWandItem extends Item {
    public enum Spell {
        AVADA_KEDAVRA("Avada Kedavra",0x22C55E), CONFRINGO("Confringo",0xEF3038),
        CRUCIO("Crucio",0xF20D25), EXPELLIARMUS("Expelliarmus",0xF4F4F4),
        IMPERIUS("Imperius",0xFFD447), PETRIFICUS_TOTALIS("Petrificus Totalis",0x999999),
        SECTUMSEMPRA("Sectumsempra",0x963DCE);
        public final String label; public final int color;
        Spell(String label,int color){this.label=label;this.color=color;}
    }
    public enum Style { AMETHYST(0xA65CFF),BONE(0xF0EEE8),CELESTIAL(0x42D9D0),DRAGON(0xF05A24),EMERALD(0x36C878),MAGMA(0xFF5B19),WIDOW(0xD9D9D9);
        public final int color;Style(int color){this.color=color;} }
    private final Spell defaultSpell; private final Style style;
    public MagicWandItem(Spell spell,Style style,Settings settings){super(settings);this.defaultSpell=spell;this.style=style;}
    public Spell defaultSpell(){return defaultSpell;} public Style style(){return style;}
    @Override public UseAction getUseAction(ItemStack stack){return UseAction.BOW;}
    @Override public int getMaxUseTime(ItemStack stack,LivingEntity user){return 20;}
    @Override public ActionResult use(World world,PlayerEntity user,Hand hand){user.setCurrentHand(hand);return ActionResult.CONSUME;}
    private void manifest(ServerPlayerEntity player,ServerWorld world,ItemStack stack,Hand hand){
        int index=WandryHP.getSelectedSpell(player.getUuid(),defaultSpell.ordinal());
        Spell spell=Spell.values()[Math.floorMod(index,Spell.values().length)];
        Vec3d direction=player.getRotationVec(1.0F).normalize();
        // Posição aproximada da ponta da varinha: à frente do olhar e deslocada para o lado da mão.
        Vec3d right=new Vec3d(-direction.z,0,direction.x).normalize();
        double side=hand==Hand.MAIN_HAND?0.34:-0.34;
        Vec3d origin=player.getEyePos().add(direction.multiply(0.62)).add(right.multiply(side)).add(0,-0.24,0);
        SpellProjectileEntity projectile=new SpellProjectileEntity(WandryHP.SPELL_PROJECTILE,world);
        projectile.refreshPositionAndAngles(origin.x,origin.y,origin.z,player.getYaw(),player.getPitch());
        projectile.configure(spell.ordinal(),style.ordinal(),direction.multiply(0.92));
        world.spawnEntity(projectile);
        player.getItemCooldownManager().set(stack,5);
    }
    @Override public boolean onStoppedUsing(ItemStack stack,World world,LivingEntity user,int remainingUseTicks){
        if(!(user instanceof ServerPlayerEntity player)||!(world instanceof ServerWorld server))return false;
        if(20-remainingUseTicks<8)return false;
        manifest(player,server,stack,player.getActiveHand()); return true;
    }
    @Override public ItemStack finishUsing(ItemStack stack,World world,LivingEntity user){
        if(user instanceof ServerPlayerEntity player && world instanceof ServerWorld server)manifest(player,server,stack,player.getActiveHand());
        return stack;
    }
}
