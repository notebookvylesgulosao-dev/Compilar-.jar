package com.wandryhp;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Montaria voadora da vassoura. O jogador é um passageiro real da entidade. */
public final class BroomEntity extends Entity {
    private float forwardInput;
    private float strafeInput;
    private float verticalInput;

    public BroomEntity(EntityType<? extends BroomEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
    }

    public void setControls(float forward, float strafe, float vertical) {
        this.forwardInput = Math.max(-1.0f, Math.min(1.0f, forward));
        this.strafeInput = Math.max(-1.0f, Math.min(1.0f, strafe));
        this.verticalInput = Math.max(-1.0f, Math.min(1.0f, vertical));
    }

    @Override
    protected void initDataTracker(net.minecraft.entity.data.DataTracker.Builder builder) { }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) { }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) { }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return passenger instanceof PlayerEntity && getPassengerList().isEmpty();
    }

    @Override
    public LivingEntity getControllingPassenger() {
        Entity passenger = getFirstPassenger();
        return passenger instanceof LivingEntity living ? living : null;
    }

    @Override
    public void tick() {
        super.tick();
        setNoGravity(true);
        LivingEntity rider = getControllingPassenger();
        if (rider == null) {
            if (!getWorld().isClient) discard();
            return;
        }

        setYaw(rider.getYaw());
        setPitch(rider.getPitch() * 0.35f);
        if (!getWorld().isClient) {
            Vec3d look = rider.getRotationVec(1.0f);
            Vec3d forward = new Vec3d(look.x, 0, look.z).normalize();
            if (forward.lengthSquared() < 0.0001) forward = Vec3d.fromPolar(0, rider.getYaw());
            Vec3d right = new Vec3d(-forward.z, 0, forward.x);
            Vec3d movement = forward.multiply(forwardInput * 0.48)
                    .add(right.multiply(strafeInput * 0.38))
                    .add(0, verticalInput * 0.38, 0);
            setVelocity(movement);
            move(MovementType.SELF, movement);
        }
    }
}
