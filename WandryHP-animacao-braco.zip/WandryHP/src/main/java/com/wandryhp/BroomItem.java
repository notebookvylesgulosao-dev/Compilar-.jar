package com.wandryhp;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Item que cria uma montaria real; não concede o voo criativo ao jogador. */
public final class BroomItem extends Item {
    public BroomItem(Settings settings) { super(settings); }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient && world instanceof ServerWorld server) {
            if (user.getVehicle() instanceof BroomEntity broom) {
                user.stopRiding();
                broom.discard();
                user.sendMessage(net.minecraft.text.Text.literal("Você desmontou da vassoura."), true);
            } else if (!user.hasVehicle()) {
                BroomEntity broom = new BroomEntity(WandryHP.BROOM_ENTITY, world);
                broom.refreshPositionAndAngles(user.getX(), user.getY() - 0.25, user.getZ(), user.getYaw(), 0.0f);
                server.spawnEntity(broom);
                if (user.startRiding(broom)) {
                    user.sendMessage(net.minecraft.text.Text.literal("Vassoura montada! Use WASD, Espaço e Shift para voar."), true);
                } else {
                    broom.discard();
                }
            }
            user.getItemCooldownManager().set(user.getStackInHand(hand), 8);
        }
        return ActionResult.SUCCESS;
    }
}
