package com.wandryhp;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record BroomControlPayload(float forward, float strafe, float vertical) implements CustomPayload {
    public static final Id<BroomControlPayload> ID = new Id<>(Identifier.of(WandryHP.MOD_ID, "broom_control"));
    public static final PacketCodec<RegistryByteBuf, BroomControlPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.FLOAT, BroomControlPayload::forward,
            PacketCodecs.FLOAT, BroomControlPayload::strafe,
            PacketCodecs.FLOAT, BroomControlPayload::vertical,
            BroomControlPayload::new);
    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
