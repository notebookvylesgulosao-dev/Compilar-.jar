package com.wandryhp.mixin.client;

import com.wandryhp.client.WandCastArmAnimation;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Aplica a animação personalizada do braço da varinha depois das poses originais do modelo. */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin<T extends BipedEntityRenderState> {
    @Shadow @Final public ModelPart head;
    @Shadow @Final public ModelPart rightArm;
    @Shadow @Final public ModelPart leftArm;

    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("TAIL"))
    private void wandryhp$animateWandArm(T state, CallbackInfo ci) {
        if (!(state instanceof PlayerEntityRenderState playerState)) return;
        WandCastArmAnimation.apply(playerState, this.head, this.rightArm, this.leftArm);
        // Garante que as mangas da skin acompanhem os braços animados.
        if ((Object) this instanceof PlayerEntityModel playerModel) {
            playerModel.leftSleeve.copyTransform(this.leftArm);
            playerModel.rightSleeve.copyTransform(this.rightArm);
        }
    }
}
